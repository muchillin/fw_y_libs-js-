$( document ).ready(function() {
  startTimer();

});


//------------------------------------------------------------------------------
function cambiaColor(){
$('.main-titulo').animate ({
  color: "blue"
},1500, function(){
  cambiaRojo()
});
}

function cambiaRojo(){
$('.main-titulo').animate ({
  color: "red"
},1500, function(){
  cambiaColor()
});
}

//es lo primero que se hace se llena------------------------------------------------------------------------------

function llenandoTablero() {
for (x = 1; x <= 7; x++) {
  for (i = 1; i <= 7; i++) {
    if ($(`.col-${i}`).children(`img:nth-child(${7})`).html() == null) {
        $(`.col-${i}`).append(`<img src="./image/${Math.floor(Math.random() * 4) + 1}.png" class='elemento' />`).css({ justifyContent: 'flex-start' });
      }
    }
  }
  mueveDulce() //los vuelve a todos dropp y dragg

}




//estan llamadas desde el inicio------------------------------------------------
//----------funcion de busqueda horizontal de dulces----------------------------
  function horizontal()
  {
  var bh=0;
  for(var j=1;j<8;j++)
  {
  for(var k=1;k<6;k++)
  {
  var res1=$(".col-"+k).children("img:nth-last-child("+j+")").attr("src")
  var res2=$(".col-"+(k+1)).children("img:nth-last-child("+j+")").attr("src")
  var res3=$(".col-"+(k+2)).children("img:nth-last-child("+j+")").attr("src")
  if((res1==res2) && (res2==res3) && (res1!=null) && (res2!=null) && (res3!=null))
  {
  $(".col-"+k).children("img:nth-last-child("+(j)+")").attr("class","elemento activo")
  $(".col-"+(k+1)).children("img:nth-last-child("+(j)+")").attr("class","elemento activo")
  $(".col-"+(k+2)).children("img:nth-last-child("+(j)+")").attr("class","elemento activo")
  bh=1;
  }
  }
  }
  return bh;
  }
  //------------------------------------------------------------------------------
  //----------Funcion de busqueda vertical de dulces------------------------------
  function vertical()
  {
  var bv=0;
  for(var l=1;l<6;l++)
  {
  for(var k=1;k<8;k++)
  {
  var res1=$(".col-"+k).children("img:nth-child("+l+")").attr("src")
  var res2=$(".col-"+k).children("img:nth-child("+(l+1)+")").attr("src")
  var res3=$(".col-"+k).children("img:nth-child("+(l+2)+")").attr("src")
  if((res1==res2) && (res2==res3) && (res1!=null) && (res2!=null) && (res3!=null))
  {
  $(".col-"+k).children("img:nth-child("+(l)+")").attr("class","elemento activo")
  $(".col-"+k).children("img:nth-child("+(l+1)+")").attr("class","elemento activo")
  $(".col-"+k).children("img:nth-child("+(l+2)+")").attr("class","elemento activo")
  bv=1;
  }
  }
  }
  return bv;
  }
  //------------------------------------------------------------------------------


movPto=0;
function analisaTablero(){
horizontal();
vertical();

  if( horizontal()== true && vertical()== true ) {

    $(".activo").hide("pulsate",2000,function(){
      $(".activo").remove()
      llenandoTablero()
      movPto = movPto + 50
      $("#score-text").html(movPto);
    })

}
}

//------------------------------------------------------------------------------

var intercambiar = false;
$(document).on("click", ".btn-reinicio", function(){
intercambiar = !intercambiar;
if (intercambiar == true) {
  $(".btn-reinicio").text("Reinicio");
  cambiaColor();
  llenandoTablero();
  analisaTablero();
  startTimer(120, '#timer');
} else {
location.reload();
}
});

//------------------------------------------------------------------------------
//esto dropea y dragea, al final llama a analizaTablero
var movTotal = 0;
function mueveDulce(){
var dulce1
var dulce2
var dulceSrc1
var dulceSrc2


$("img").draggable({
  revert:"valid",
  containment:".panel-tablero",
  start : function (event, ui){
    dulce1 = this
    dulceSrc1 = $(this).attr("src")
  }
})

$("img").droppable({
  drop: function (event, ui){
    dulce2 = this
    dulceSrc2 = $(this).attr("src")
    $(dulce2).attr("src", dulceSrc1)
    $(dulce1).attr("src", dulceSrc2)
    movTotal = movTotal + 1
    $("#movimientos-text").html(movTotal);
    setTimeout(analisaTablero, 500)
  }
})
}
//-----
