//para controlar el tiempo del juego

function startTimer(duration, display) {
    var timer = duration, minutes, seconds;
    var interval= setInterval(function () {
        minutes = parseInt(timer / 60, 10)
        seconds = parseInt(timer % 60, 10);

        minutes = minutes < 10 ? "0" + minutes : minutes;
        seconds = seconds < 10 ? "0" + seconds : seconds;

        $(display).text(minutes + ":" + seconds);

        if (--timer < 0) {
            $("body").trigger("finTiempo");
						clearInterval(interval);
            $("#contenedor").hide("slow");
            $("#tiempo").hide("slow");
            //$(".col-1").preppend("Final del Juego");

            setTimeout(function(){
            $("#scores").animate({
              width:'1200px'
            });
            $("#movimientos").animate({
              width:'1200px'
            });
            $("#botones").animate({
              width:'1200px'
            });
          }, 1000);
        }
    }, 1000);
}
